Interface for interfacing with existing computer vision databases 
=================================================================

In the src directory, there is code for reading many of the existing computer vision databases.

In the samples directory, there are examples of using the above code to read, train and test on the data.
