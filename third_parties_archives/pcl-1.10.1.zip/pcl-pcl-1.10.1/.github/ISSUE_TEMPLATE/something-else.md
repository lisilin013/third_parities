---
name: Something else
about: It's none of the above
title: "[custom] Provide a general summary of the issue"
labels: 'status: triage'
assignees: ''

---

<!--- WARNING: This is an issue tracker. Before opening a new issue make sure you read https://github.com/PointCloudLibrary/pcl/blob/master/CONTRIBUTING.md#using-the-issue-tracker. -->
